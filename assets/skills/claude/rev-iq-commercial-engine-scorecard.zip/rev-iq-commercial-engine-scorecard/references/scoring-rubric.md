# Scoring rubric: 1 = broken or nonexistent, 5 = strong and proven

Score on evidence, not intent. A plan, a belief or "we're about to" is a 1 or 2. Use the anchors below; when evidence sits between two anchors, take the lower score.

## Acquisition
1. No identifiable source of qualified prospects; new interest is accidental.
2. One source, usually the founder's network, irregular and unmeasured.
3. One or two sources producing a steady, roughly known monthly flow.
4. Several sources, volume tracked monthly, with a clear next step for every new prospect.
5. Repeatable, measured channels the business can scale up with spend or effort, with a known cost per qualified prospect.

## Conversion
1. No defined sales process; deals happen, or don't, without a pattern.
2. Some deals close, but the conversion rate and cycle time are unknown.
3. Rough conversion rate and cycle time known; the main stall point has been identified.
4. Defined stages and qualification, conversion tracked, stall points actively worked.
5. Conversion and cycle time are predictable enough to forecast from.

## Pricing
1. Price set by guesswork or copied from a competitor; structure doesn't fit how customers get value.
2. A price exists, but it has never been tested and prospects regularly push back on it or misunderstand it.
3. Price and structure broadly fit the value delivered; pushback is occasional and specific.
4. Pricing has been deliberately reviewed against value and willingness to pay; packaging supports upgrades.
5. Pricing is tested, reviewed regularly, and actively contributes to conversion and expansion.

## Retention
1. Customers regularly leave within the first few months, and the reasons are unknown.
2. Churn is noticeable; reasons are guessed at, and there is no structured onboarding.
3. Most recent customers are still paying; the main churn reasons are known; onboarding is basic.
4. Retention is tracked monthly, onboarding is defined, and early drop-off is actively managed.
5. Retention is strong and stable across cohorts, with churn reasons that are addressable rather than existential.

If the business has no paying customers yet, score retention 1 with the evidence "no customers yet" and do not select it as the constraint.

## Expansion
1. No customer pays more than at the start, and there is no upgrade path.
2. An upgrade path exists in theory, but nobody has asked a customer to expand.
3. Some customers have expanded, mostly unprompted.
4. Expansion is deliberately pursued with existing accounts, and the upgrade path is clear.
5. Expansion is a reliable, measured source of growth that offsets churn.
