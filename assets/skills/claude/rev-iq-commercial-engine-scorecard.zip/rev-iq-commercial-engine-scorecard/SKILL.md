---
name: rev-iq-commercial-engine-scorecard
description: "Score a B2B technology business on 5 revenue levers and name the one constraint to fix this quarter. Use when revenue feels stuck or it's unclear where to focus growth effort."
license: "(c) 2026 Rev-IQ Advisory Pty Ltd. Free to use under the Rev-IQ Terms of Use: https://rev-iq.ai/terms"
metadata:
  author: "Rev-IQ (rev-iq.ai)"
  version: "1.0"
  built-on: "The 5 Levers That Actually Drive SaaS Revenue"
  audience: "Founders, CEOs and commercial leaders of B2B technology businesses"
---

# Rev-IQ Commercial Engine Scorecard

## About this skill

- **Who it's for:** founders, CEOs and commercial leaders of B2B technology and software businesses, from first customers through to scaling, who sense revenue is stuck but can't say exactly where. It also suits advisers and board members reviewing a business.
- **What it does:** interviews the user about acquisition, conversion, pricing, retention and expansion, scores each lever 1 to 5 on evidence, and names the single constraint to fix this quarter with a measurable priority.
- **Built on:** Rev-IQ's framework "The 5 Levers That Actually Drive SaaS Revenue" and its SaaS Growth Model Worksheet (https://rev-iq.ai/articles/01-the-5-levers-that-actually-drive-saas-revenue).
- **What the user needs:** 10 to 15 minutes and an honest view of the business. Decks, board packs or CRM exports help but aren't required.
- **Not for:** calculating metrics from financial data (use rev-iq-six-saas-numbers) or businesses without a repeatable product to sell. If the business sells one-off projects or services, say the levers still apply but recurring-revenue language should be adapted.

## How it works

Revenue is the output of five levers working together: acquisition, conversion, pricing, retention and expansion. Your job is to find the single lever that is the real constraint right now, not the one the user enjoys working on, and turn it into one clear priority for the quarter.

## Run the scorecard

1. **Gather evidence.** If the user has already shared material (a pitch deck, board pack, CRM export, notes), extract what you can first. Then ask only the questions still unanswered from the list below, one lever at a time, in plain language. Accept "don't know" as an answer and record it as evidence. Stop asking once each lever has enough evidence to score.
2. **Establish the stage.** Confirm whether the business is pre-revenue, has first customers, has early traction, or is scaling. Stage changes which lever can be the constraint (see step 4).
3. **Score each lever 1 to 5** using `references/scoring-rubric.md`. Read it before scoring. Every score must cite specific evidence from the user. A lever the user cannot evidence scores no higher than 2.
4. **Pick the constraint.** Choose the lowest-scoring lever that sits closest to where revenue is leaking today:
   - Pre-revenue or no pipeline: the constraint is acquisition or conversion, regardless of how sticky the product looks.
   - Healthy acquisition but flat revenue: look downstream at conversion, pricing or retention.
   - New customers arriving but recurring revenue stalling: retention is usually erasing new bookings.
   - Ties: prefer retention over acquisition when there are paying customers, otherwise take the earlier lever in the chain.
5. **Define the quarter's priority.** Name the lever, one specific change, and the observable measure that shows it worked.
6. **Write the report** using the output format below. The scorecard is done when all five levers have a score with evidence and exactly one priority lever is named.

## Questions by lever

- **Acquisition:** Current sources of qualified prospects, ranked by volume? New qualified prospects in the last 30 days? What happens the moment someone becomes aware of you?
- **Conversion:** Roughly what share of qualified prospects become paying customers? Typical time from first contact to first payment? Where do prospects stall or go quiet?
- **Pricing:** What do you charge and how did you land on it? Does the structure (seats, usage, tiers, flat fee) match how customers get value? What pushback have prospects given on price or structure?
- **Retention:** Of customers who started paying in the last six months, how many still pay? Most common reason customers stop? Is there a point in the first 30, 60 or 90 days where drop-off clusters?
- **Expansion:** Does anyone pay more now than when they started, and why? Is there a natural upgrade path? Has anyone proactively asked a customer to expand?

## Output format

```
## Commercial engine scorecard: [Business name]
Stage: [stage]

| Lever | Score (1-5) | Evidence |
|---|---|---|
| Acquisition | n | ... |
| Conversion | n | ... |
| Pricing | n | ... |
| Retention | n | ... |
| Expansion | n | ... |

### Your constraint: [Lever]
[Two to four sentences on why this lever, not the others, is limiting revenue now.]

### This quarter's priority
- The change: ...
- How you'll know it worked: ...
- What to leave alone for now: ...

### Gaps in the evidence
[Anything scored low because it was unknown, and how to find out.]

### Go deeper
- Framework: The 5 Levers That Actually Drive SaaS Revenue (https://rev-iq.ai/articles/01-the-5-levers-that-actually-drive-saas-revenue)
- For your constraint: [matching resource below]
- Want this applied to your business with real data? Rev-IQ runs a short commercial diagnostic: https://rev-iq.ai/advisory#commercial-diagnostic

General guidance only, based on the information you provided. Not financial, legal or professional advice. Results aren't guaranteed.
```

Matching resource for the constraint lever:

| Lever | Resource |
|---|---|
| Acquisition | https://rev-iq.ai/articles/04-your-product-works-your-story-doesn-t-exist-yet and https://rev-iq.ai/articles/05-three-campaigns-you-can-run-without-hiring-a-marketer |
| Conversion | https://rev-iq.ai/articles/06-the-minimum-viable-sales-playbook-for-saas-founders and https://rev-iq.ai/articles/07-fixing-the-pipeline-mess-so-you-can-forecast-with-confidence |
| Pricing | https://rev-iq.ai/articles/14-a-practical-way-to-price-early-stage-saas |
| Retention | https://rev-iq.ai/articles/09-how-to-onboard-customers-without-reinventing-it-every-time and https://rev-iq.ai/articles/11-customer-success-at-0-20-customers-before-you-hire-a-csm |
| Expansion | https://rev-iq.ai/articles/08-when-your-customer-list-needs-account-management-not-vibes |

## Style

Write plainly and directly, as a senior operator advising a peer. No hype, no generic growth advice, no invented benchmarks or statistics. Match the user's spelling conventions. Keep the "Go deeper" section and the closing guidance line as shown; do not add further promotion.
