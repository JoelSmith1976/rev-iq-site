#!/usr/bin/env python3
"""Rev-IQ Pipeline Health Check.

Usage:
  python3 pipeline_check.py --csv deals.csv [--today 2026-10-12] [--map map.json]
                            [--stage-days stage_days.json] [--dayfirst | --monthfirst]

deals.csv: a deal or opportunity export from any CRM (open and recently closed deals).
Columns are detected from common CRM header names. Override with --map, e.g.
  {"stage": "Deal Stage", "stage_entered": "Date entered current stage", "value": "Amount"}
Fields: name, owner, stage, stage_entered, value, close_date, next_step, next_step_date,
        last_activity, source, created, reason

--stage-days: max days per stage, e.g. {"Discovery": 7, "Proposal": 14}. Stages not listed get
Rev-IQ defaults by keyword (discovery 7, qualified 10, solution 14, proposal/commercial 14,
verbal/commit/contract 10), else 14 (reported as an assumption).
Prints JSON with summary, stage table, field gaps, deal issues and win/loss patterns.
"""
import argparse, csv, json, re, sys
from collections import Counter, defaultdict
from datetime import date, datetime

ALIASES = {
    "name": ["deal name", "opportunity name", "deal", "opportunity", "title", "name"],
    "owner": ["deal owner", "opportunity owner", "owner", "assigned to", "sales rep", "rep", "user"],
    "stage": ["deal stage", "stage", "pipeline stage", "sales stage", "status"],
    "stage_entered": ["date entered current stage", "stage entry date", "stage entered", "entered stage",
                      "last stage change date", "stage change date", "stage changed", "stage date"],
    "value": ["amount", "deal value", "value", "deal amount", "expected revenue", "opportunity amount", "total"],
    "close_date": ["expected close date", "close date", "closing date", "closed date", "close"],
    "next_step": ["next step", "next action", "next steps"],
    "next_step_date": ["next step date", "next activity date", "next action date", "next task date"],
    "last_activity": ["last activity date", "last activity", "last contacted", "last contact date", "last engagement date"],
    "source": ["original source", "lead source", "deal source", "source"],
    "created": ["create date", "created date", "created", "date created", "created time"],
    "reason": ["closed lost reason", "loss reason", "lost reason", "win/loss reason", "reason"],
    "won_reason": ["closed won reason", "won reason", "win reason"],
}
DEFAULT_DAYS = [("discover", 7), ("qualif", 10), ("solution", 14), ("demo", 14), ("proposal", 14),
                ("commercial", 14), ("negotiat", 14), ("quote", 14), ("verbal", 10), ("commit", 10), ("contract", 10)]
REQUIRED = ["owner", "stage", "stage_entered", "value", "close_date", "next_step", "source"]


def detect(headers, override):
    low = {h.strip().lower(): h for h in headers}
    cols = {}
    for f, names in ALIASES.items():
        if override.get(f):
            cols[f] = override[f]; continue
        for n in names:
            if n in low:
                cols[f] = low[n]; break
        else:
            for n in names:
                hit = next((h for k, h in low.items() if n in k and h not in cols.values()), None)
                if hit and len(n) > 4:
                    cols[f] = hit; break
    return cols


def date_order(values):
    first = second = False
    for v in values:
        m = re.match(r"^\s*(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})", v or "")
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            first |= a > 12; second |= b > 12
    if first and not second:
        return "dayfirst", False
    if second and not first:
        return "monthfirst", False
    return "dayfirst", True


def pdate(v, order):
    v = (v or "").strip()
    if not v:
        return None
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", v)
    if m:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    m = re.match(r"^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})", v)
    if m:
        a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        y += 2000 if y < 100 else 0
        d, mo = (a, b) if order == "dayfirst" else (b, a)
        try:
            return date(y, mo, d)
        except ValueError:
            return None
    for fmt in ("%d %b %Y", "%d %B %Y", "%b %d, %Y", "%B %d, %Y"):
        try:
            return datetime.strptime(v, fmt).date()
        except ValueError:
            pass
    return None


def money(v):
    s = re.sub(r"[^\d.\-]", "", str(v or ""))
    try:
        return float(s) if s not in ("", "-", ".") else None
    except ValueError:
        return None


def status(stage):
    s = (stage or "").lower()
    if "won" in s:
        return "won"
    if "lost" in s or "disqualif" in s:
        return "lost"
    return "open"


def max_days(stage, custom, assumed):
    if stage in custom:
        return custom[stage]
    for k, d in DEFAULT_DAYS:
        if k in (stage or "").lower():
            return d
    assumed.add(stage)
    return 14


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--today")
    ap.add_argument("--map")
    ap.add_argument("--stage-days")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--dayfirst", action="store_true")
    g.add_argument("--monthfirst", action="store_true")
    a = ap.parse_args()
    today = date.fromisoformat(a.today) if a.today else date.today()
    override = json.load(open(a.map)) if a.map else {}
    custom = json.load(open(a.stage_days)) if a.stage_days else {}
    with open(a.csv, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        print(json.dumps({"error": "no rows"})); return
    cols = detect(rows[0].keys(), override)
    notes = []
    get = lambda r, f: (r.get(cols[f]) or "").strip() if f in cols else ""
    datevals = [get(r, f) for r in rows for f in ("stage_entered", "close_date", "next_step_date", "last_activity", "created")]
    if a.dayfirst or a.monthfirst:
        order, ambiguous = ("dayfirst" if a.dayfirst else "monthfirst"), False
    else:
        order, ambiguous = date_order(datevals)
    if ambiguous and any(re.match(r"^\d{1,2}/\d{1,2}/", v) for v in datevals):
        notes.append("Dates were ambiguous (no day above 12); read as day/month/year. Confirm with the user.")
    missing_cols = [f for f in REQUIRED if f not in cols]
    if missing_cols:
        notes.append("Columns not found in export: " + ", ".join(missing_cols) + ". Checks that need them were skipped.")

    assumed = set()
    open_deals, closed = [], []
    stage_tbl = defaultdict(lambda: {"open_deals": 0, "value": 0.0, "over_limit": 0, "max_days": None, "days_in_stage": []})
    field_gaps = Counter()
    for r in rows:
        st = get(r, "stage")
        s = status(st)
        d = {"name": get(r, "name") or "(unnamed)", "owner": get(r, "owner"), "stage": st,
             "value": money(get(r, "value")), "issues": []}
        if s != "open":
            d["outcome"] = s
            if s == "won" and "won_reason" in cols:
                d["reason"] = get(r, "won_reason")
            elif s == "won" and "lost" in cols.get("reason", "").lower():
                d["reason"] = None; d["skip_reason"] = True
            else:
                d["reason"] = get(r, "reason")
            d["closed"] = pdate(get(r, "close_date"), order)
            closed.append(d); continue
        for f in REQUIRED:
            if f in cols and not get(r, f):
                field_gaps[f] += 1
        entered = pdate(get(r, "stage_entered"), order)
        close = pdate(get(r, "close_date"), order)
        nsd = pdate(get(r, "next_step_date"), order)
        last = pdate(get(r, "last_activity"), order)
        lim = max_days(st, custom, assumed)
        t = stage_tbl[st]; t["open_deals"] += 1; t["value"] += d["value"] or 0; t["max_days"] = lim
        if entered:
            days = (today - entered).days
            d["days_in_stage"] = days; t["days_in_stage"].append(days)
            if days > lim:
                d["issues"].append(f"stalled: {days} days in stage (limit {lim})"); t["over_limit"] += 1
        if "next_step" in cols and not get(r, "next_step"):
            d["issues"].append("no next step")
        if "next_step_date" in cols and get(r, "next_step") and not nsd:
            d["issues"].append("next step has no date")
        if "last_activity" in cols and not last:
            d["issues"].append("no activity recorded")
        if nsd and nsd < today:
            d["issues"].append(f"next step overdue since {nsd.isoformat()}")
        if close and close < today:
            d["issues"].append(f"close date in the past ({close.isoformat()})")
        if "close_date" in cols and not close:
            d["issues"].append("no close date")
        if last and (today - last).days >= 7:
            d["issues"].append(f"no activity for {(today - last).days} days")
        if "owner" in cols and not d["owner"]:
            d["issues"].append("no owner")
        if d["value"] is None:
            d["issues"].append("no value")
        open_deals.append(d)

    total = sum(x["value"] or 0 for x in open_deals)
    critical = ("stalled", "close date in the past", "no next step", "next step overdue")
    trusted = [x for x in open_deals if not any(i.startswith(critical) for i in x["issues"])]
    trusted_val = sum(x["value"] or 0 for x in trusted)
    top = max((x["value"] or 0 for x in open_deals), default=0)
    if closed and "reason" not in cols and "won_reason" not in cols:
        notes.append("No win/loss reason field in the export. Adding one is the first fix.")
    lost = [x for x in closed if x["outcome"] == "lost"]
    won = [x for x in closed if x["outcome"] == "won"]
    no_reason = [x["name"] for x in closed if not x.get("reason") and not x.get("skip_reason")]
    if any(x.get("skip_reason") for x in closed):
        notes.append("The export only has a lost-reason field, so won deals weren't checked. Add a won-reason field so wins are explained too.")
    out = {
        "today": today.isoformat(), "date_format": order, "columns_detected": cols,
        "summary": {
            "open_deals": len(open_deals), "open_value": round(total),
            "trusted_deals": len(trusted), "trusted_value": round(trusted_val),
            "trusted_share_pct": round(100 * trusted_val / total, 1) if total else None,
            "deals_with_issues": sum(1 for x in open_deals if x["issues"]),
            "largest_deal_share_pct": round(100 * top / total, 1) if total else None,
            "closed_won": len(won), "closed_lost": len(lost),
            "win_rate_pct": round(100 * len(won) / len(closed), 1) if closed else None,
            "closed_without_reason": len(no_reason),
        },
        "stages": {k: {"open_deals": v["open_deals"], "value": round(v["value"]), "max_days": v["max_days"],
                       "over_limit": v["over_limit"],
                       "median_days": sorted(v["days_in_stage"])[len(v["days_in_stage"]) // 2] if v["days_in_stage"] else None}
                   for k, v in stage_tbl.items()},
        "field_gaps_open_deals": dict(field_gaps),
        "issue_counts": dict(Counter(i.split(":")[0].split(" (")[0].split(" since")[0].split(" for ")[0]
                                     for x in open_deals for i in x["issues"])),
        "deals_with_issues": sorted([{k: x[k] for k in ("name", "owner", "stage", "value", "issues")} for x in open_deals if x["issues"]],
                                    key=lambda x: -(x["value"] or 0)),
        "loss_reasons": dict(Counter(x["reason"] or "(none recorded)" for x in lost)),
        "closed_without_reason": no_reason,
        "notes": notes,
    }
    if assumed:
        notes.append("No time limit known for stages " + ", ".join(sorted(s for s in assumed if s)) + "; assumed 14 days. Ask the user for their typical days per stage.")
    json.dump(out, sys.stdout, indent=2)
    print()


if __name__ == "__main__":
    main()
