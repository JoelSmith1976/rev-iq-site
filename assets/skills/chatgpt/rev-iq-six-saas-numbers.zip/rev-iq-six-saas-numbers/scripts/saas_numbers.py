#!/usr/bin/env python3
"""Rev-IQ Six SaaS Numbers calculator.

Usage:
  python3 saas_numbers.py --inputs inputs.json [--mrr customer_mrr.csv]

customer_mrr.csv (optional): recurring revenue per customer per month.
  Long format: customer,month,mrr   (month as YYYY-MM)
  Wide format: customer,2026-01,2026-02,...
  Exclude setup fees, services and one-off charges. Annual prepayments: use the monthly equivalent.

inputs.json: monthly finance figures, keyed by month (YYYY-MM). All optional except what you have:
  {
    "currency": "AUD",
    "months": {
      "2026-09": {
        "sm_spend": 42000,          # fully loaded sales + marketing incl. salaries
        "gross_margin_pct": 78,      # recurring gross margin %
        "cash": 610000,              # cash in bank at month end
        "net_burn": 55000,           # cash out minus cash in (positive = burning)
        "mrr": 98000,                # only needed if no customer CSV
        "new_mrr": 6000, "expansion_mrr": 1500, "contraction_mrr": 500, "churned_mrr": 2500,
        "new_customers": 4
      }
    }
  }
Customer CSV figures take precedence over manual MRR fields.
Prints a JSON result with metrics, flags and data notes.
"""
import argparse, csv, json, re, sys
from collections import defaultdict

MONTH = re.compile(r"^\d{4}-\d{2}$")


def load_mrr(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    head = [h.strip().lower() for h in rows[0]]
    data = defaultdict(dict)  # customer -> month -> mrr
    if {"customer", "month", "mrr"} <= set(head):
        ci, mi, vi = head.index("customer"), head.index("month"), head.index("mrr")
        for r in rows[1:]:
            if len(r) <= max(ci, mi, vi) or not r[ci].strip():
                continue
            data[r[ci].strip()][r[mi].strip()[:7]] = num(r[vi])
    else:
        months = [(i, h) for i, h in enumerate(rows[0]) if MONTH.match(h.strip()[:7])]
        for r in rows[1:]:
            if not r or not r[0].strip():
                continue
            for i, m in months:
                if i < len(r):
                    data[r[0].strip()][m.strip()[:7]] = num(r[i])
    return data


def num(v):
    if v is None:
        return 0.0
    s = str(v).replace(",", "").replace("$", "").strip()
    return float(s) if s not in ("", "-") else 0.0


def movements(data):
    months = sorted({m for c in data.values() for m in c})
    out = {}
    for i, m in enumerate(months):
        cur = {c: v.get(m, 0.0) for c, v in data.items()}
        res = {"mrr": sum(cur.values()), "customers": sum(1 for v in cur.values() if v > 0)}
        if i > 0:
            prev = {c: v.get(months[i - 1], 0.0) for c, v in data.items()}
            new = exp = con = churn = 0.0
            new_n = churn_n = 0
            new_by = {}
            for c in data:
                p, q = prev[c], cur[c]
                if p == 0 and q > 0:
                    new += q; new_n += 1; new_by[c] = q
                elif p > 0 and q == 0:
                    churn += p; churn_n += 1
                elif q > p:
                    exp += q - p
                elif q < p:
                    con += p - q
            start = sum(prev.values())
            res.update(start_mrr=start, new_mrr=new, expansion_mrr=exp, contraction_mrr=con,
                       churned_mrr=churn, new_customers=new_n, churned_customers=churn_n,
                       largest_new=max(new_by.values()) if new_by else 0.0)
        out[m] = res
    return out


def pct(a, b):
    return round(100 * a / b, 2) if b else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inputs", required=True)
    ap.add_argument("--mrr")
    a = ap.parse_args()
    cfg = json.load(open(a.inputs))
    fin = cfg.get("months", {})
    notes = []
    mv = movements(load_mrr(a.mrr)) if a.mrr else {}
    months = sorted(set(fin) | set(mv))
    series = {}
    for m in months:
        r = dict(fin.get(m, {}))
        r.update({k: v for k, v in mv.get(m, {}).items()})
        if "start_mrr" not in r and m != months[0]:
            prev = series.get(months[months.index(m) - 1], {})
            if prev.get("mrr") is not None:
                r["start_mrr"] = prev["mrr"]
        s = r.get("start_mrr")
        if s:
            lost = r.get("churned_mrr", 0) + r.get("contraction_mrr", 0)
            if "churned_mrr" in r or "contraction_mrr" in r:
                r["gross_churn_pct"] = pct(lost, s)
                r["net_churn_pct"] = pct(lost - r.get("expansion_mrr", 0), s)
        if r.get("mrr") is not None:
            r["arr"] = r["mrr"] * 12
        series[m] = r

    last = months[-1]
    L = series[last]
    window = months[-3:] if len(months) >= 3 else months
    sm = [series[m].get("sm_spend") for m in window]
    newc = [series[m].get("new_customers") for m in window]
    newm = [series[m].get("new_mrr") for m in window]
    gm = L.get("gross_margin_pct")
    res = {"currency": cfg.get("currency", ""), "latest_month": last, "months": series, "summary": {}, "flags": {}, "notes": notes}
    S, F = res["summary"], res["flags"]
    S["mrr"] = L.get("mrr"); S["arr"] = L.get("arr")
    S["gross_churn_pct"] = L.get("gross_churn_pct"); S["net_churn_pct"] = L.get("net_churn_pct")

    # MRR trend
    mrrs = [series[m].get("mrr") for m in months if series[m].get("mrr") is not None]
    if len(mrrs) >= 3 and mrrs[-1] <= mrrs[-2] <= mrrs[-3]:
        F["mrr"] = "needs attention: flat or declining for 2+ consecutive months"
    elif len(mrrs) >= 2:
        F["mrr"] = "healthy: growing month over month" if mrrs[-1] > mrrs[-2] else "watch: flat or down this month"
    wn = [series[m] for m in window if series[m].get("new_mrr") is not None]
    tot_new = sum(r["new_mrr"] for r in wn)
    n_new = sum(r.get("new_customers") or 0 for r in wn)
    if tot_new and n_new >= 3:
        top = max(r.get("largest_new", 0) for r in wn)
        if top / tot_new > 0.5:
            F["new_mrr"] = "needs attention: one customer supplied over half of new MRR in the last %d months" % len(wn)
        else:
            F["new_mrr"] = "healthy: new MRR spread across several customers"

    # Churn trends
    gcs = [series[m].get("gross_churn_pct") for m in months if series[m].get("gross_churn_pct") is not None]
    if len(gcs) >= 3:
        prior = sum(gcs[:-1]) / len(gcs[:-1])
        F["gross_churn"] = ("needs attention: latest month well above the recent average" if gcs[-1] > prior * 1.5 and gcs[-1] - prior >= 0.5
                            else "rising trend" if gcs[-1] > gcs[-2] > gcs[-3] else "stable")
        if F["gross_churn"] == "rising trend":
            F["gross_churn"] = "needs attention: rising three months running"
    ncs = [series[m].get("net_churn_pct") for m in months if series[m].get("net_churn_pct") is not None]
    if ncs:
        if len(ncs) >= 2 and ncs[-1] > 0 and ncs[-2] > 0:
            F["net_churn"] = "needs attention: consistently positive, the existing base is shrinking"
        else:
            F["net_churn"] = "healthy: at or below zero" if ncs[-1] <= 0 else "watch: positive this month"
        if len(gcs) >= 2 and len(ncs) >= 2 and ncs[-1] <= ncs[-2] and gcs[-1] > gcs[-2]:
            notes.append("Net churn improved or held while gross churn worsened: expansion is masking a retention problem.")

    # CAC, payback, LTV
    if all(v is not None for v in sm) and all(v is not None for v in newc) and sum(newc) > 0:
        cac = sum(sm) / sum(newc)
        S["cac"] = round(cac)
        S["cac_window_months"] = len(window)
        cacs = [series[m]["sm_spend"] / series[m]["new_customers"] for m in months
                if series[m].get("sm_spend") is not None and series[m].get("new_customers")]
        if len(cacs) >= 3 and cacs[-1] > cacs[-2] > cacs[-3]:
            F["cac"] = "needs attention: rising three months running"
        if gm and all(v is not None for v in newm):
            arpa_new = sum(newm) / sum(newc)
            if arpa_new > 0:
                pb = cac / (arpa_new * gm / 100)
                S["cac_payback_months"] = round(pb, 1)
                F["cac_payback"] = ("healthy: roughly under 12 months" if pb <= 12 else
                                    "watch: past 12 months" if pb <= 18 else
                                    "needs attention: well past a year")
        if gm and L.get("mrr") and L.get("customers") and gcs:
            avg_churn = sum(gcs[-3:]) / len(gcs[-3:]) / 100
            arpa = L["mrr"] / L["customers"]
            if avg_churn > 0:
                ltv = arpa * gm / 100 / avg_churn
                S["ltv_estimate"] = round(ltv)
                S["ltv_to_cac"] = round(ltv / cac, 1)
                F["ltv"] = "needs attention: close to or below CAC" if ltv < 1.5 * cac else "healthy: comfortably exceeds CAC (directional)"
            else:
                notes.append("No churn in the period, so LTV is not meaningful yet.")
        elif gm:
            notes.append("LTV not estimated: needs a paying customer count and churn figures.")
    else:
        notes.append("CAC not calculated: needs fully loaded sales and marketing spend and new customer counts for the same months.")
    if not gm:
        notes.append("Gross margin missing: CAC payback and LTV need it.")

    # Runway
    cash, burn = L.get("cash"), L.get("net_burn")
    if cash is not None and burn is not None:
        if burn <= 0:
            S["runway_months"] = None
            F["runway"] = "healthy: cash generative this month"
        else:
            rw = cash / burn
            S["runway_months"] = round(rw, 1)
            F["runway"] = ("needs attention: under 6 months" if rw < 6 else
                           "watch: 6 to 12 months" if rw < 12 else "healthy: 12 months or more")
    else:
        notes.append("Runway not calculated: needs month-end cash and net burn.")
    json.dump(res, sys.stdout, indent=2, default=lambda x: round(x, 2))
    print()


if __name__ == "__main__":
    main()
