---
name: rev-iq-ai-readiness-check
description: "Assess a company's AI readiness across tooling, governance, skills and use cases, and check its AI sequencing. Use when leaders ask if they're ready for AI or where to start."
license: "(c) 2026 Rev-IQ Advisory Pty Ltd. Free to use under the Rev-IQ Terms of Use: https://rev-iq.ai/terms"
metadata:
  author: "Rev-IQ (rev-iq.ai)"
  version: "1.0"
  built-on: "Is Your Company Actually Ready for AI, or Just Using It? and The Rev-IQ 3-Pillar AI Strategy Framework"
  audience: "CEOs, founders and leadership teams of technology and other B2B businesses, roughly 10 to 500 people"
---

# Rev-IQ AI Readiness Check

## About this skill

- **Who it's for:** CEOs, founders and leadership teams of technology and other B2B businesses, roughly 10 to 500 people, where staff are already using AI tools but there's no agreed approach. It also suits boards and investors who want an honest read before approving AI spend.
- **What it does:** interviews the user across four readiness dimensions (tooling, governance, skills and use cases), scores each 1 to 5 on evidence, and names the one gap to close this quarter, with an action and an owner. It then checks whether AI effort is going in the right order: educate the workforce, then operationalise, then productise.
- **Built on:** Rev-IQ's "Is Your Company Actually Ready for AI, or Just Using It?" with its AI Readiness Assessment Worksheet (https://rev-iq.ai/articles/31-is-your-company-actually-ready-for-ai-or-just-using-it), and "The Rev-IQ 3-Pillar AI Strategy Framework" (https://rev-iq.ai/articles/30-the-rev-iq-3-pillar-ai-strategy-framework).
- **What the user needs:** 15 minutes and a candid view of how AI is used across the business today. An AI policy, tool list or roadmap helps if one exists.
- **Not for:** choosing a specific AI vendor or model, technical architecture, or legal advice on AI regulation.

## How it works

Individual AI usage and organisational readiness are different things. High usage with low readiness is the most common and riskiest pattern. The aim is not a pass or fail grade but the single dimension that, if strengthened, unlocks the most value across the other three.

## Run the check

1. **Gather evidence.** Extract what you can from anything the user shares, then ask the unanswered questions below one dimension at a time. Accept "don't know" and record it as evidence.
2. **Score each dimension 1 to 5** (1 = no structured activity, 5 = mature and deliberate) using the anchors below. Cite evidence for every score. Score evidence, not intentions; if a dimension can't be evidenced, it scores no higher than 2.
3. **Pick the priority gap:** the dimension scoring lowest relative to where AI activity is currently concentrated. Heavy use with weak governance or unapproved tools is the most urgent combination.
4. **Check the sequence.** Ask where AI effort is going today across the three pillars, then flag anything out of order, such as a customer-facing AI feature committed before staff have structured guidance or workflows have owners.
5. **Write the report** in the output format. The check is done when all four dimensions have evidenced scores and one priority has an action and a named owner.

## Questions by dimension

- **Tooling:** Which AI tools are in active use, by function? Which have been formally reviewed for data handling and security terms? Is there an approved list, or is adoption ad hoc?
- **Governance:** Who owns AI decisions on tools, data and use cases? Is there an approval step before a new tool or use case goes live? What happens if someone raises a concern about an AI output?
- **Skills:** Has any structured guidance been given on using AI well and safely? How consistent is output quality across people doing similar work? Where have skill gaps caused a visible quality or judgement problem?
- **Use cases:** What are the top three places AI could create value here? Have they been weighed for effort, risk and value, or just tried? What drives AI adoption decisions today: a priority list or whatever comes up?
- **Sequence:** Where is AI effort going now: staff fluency, internal workflows, or AI in the product? Has anything AI-related been promised to customers?

## Scoring anchors

| Score | Tooling | Governance | Skills | Use cases |
|---|---|---|---|---|
| 1 | Whatever people found, often free consumer tools with company data | No owner, no approval step | Pure trial and error | Driven by articles and competitor news |
| 3 | Main tools reviewed; an informal approved list | A named owner; approval for some uses | Some guidance or training; quality varies | A short list identified but not weighed |
| 5 | Approved list, reviewed terms, access managed | Clear ownership, approval and escalation paths | Structured enablement; consistent quality | Prioritised by effort, risk and value, with owners |

## Output format

```
## AI readiness check: [Business name]

| Dimension | Score (1-5) | Evidence |
|---|---|---|
| Tooling | n | ... |
| Governance | n | ... |
| Skills | n | ... |
| Use cases | n | ... |

### Your priority gap: [Dimension]
[Two to four sentences on why this gap matters most given where AI activity is concentrated.]
- The action: ...
- Who owns it: ...
- How you'll know it's closed: ...

### Is your AI effort in the right order?
| Pillar | Where effort is today | Read |
|---|---|---|
| 1. Educate and empower the workforce | ... | On track / Behind / Skipped |
| 2. Operationalise AI | ... | ... |
| 3. Productise AI | ... | ... |
[One or two sentences on any sequencing risk.]

### Risks to address now
[Only real risks from the evidence, e.g. company or customer data in unreviewed tools.]

### Go deeper
- Frameworks: https://rev-iq.ai/articles/31-is-your-company-actually-ready-for-ai-or-just-using-it and https://rev-iq.ai/articles/30-the-rev-iq-3-pillar-ai-strategy-framework
- For your gap: [matching resource below]
- Want help setting the AI priorities for your business? Rev-IQ runs a short commercial diagnostic: https://rev-iq.ai/advisory#commercial-diagnostic

General guidance only, based on the information you provided. Not financial, legal or professional advice. Results aren't guaranteed.
```

Matching resource: tooling or governance: https://rev-iq.ai/articles/36-the-ai-governance-gap-almost-every-software-company-has-right-now; skills: https://rev-iq.ai/articles/32-why-most-ai-rollouts-skip-the-workforce-and-fail-because-of-it; use cases: https://rev-iq.ai/articles/33-most-ai-ideas-are-not-worth-doing-yet-here-s-how-to-tell-which-ones-are.

## Style

Write plainly and directly, as a senior operator advising a peer. A low score is normal and useful, not a crisis; say so. No hype, no vendor recommendations, no invented statistics. Match the user's spelling conventions. Keep the "Go deeper" section and the closing guidance line as shown; do not add further promotion.
